//
function howMuchLeftOverCake(numSlices, numPeople){
    var remainSlices = numSlices % numPeople;
    if (remainSlices == 0){
        return "No leftovers for you!";
    }
    else if(remainSlices <= 2){
        return "You have some leftovers.";
    }
    else if( 3 <= remainSlices <= 5){
        return "You have leftovers to share." 
    }
    else if(remainSlices > 5 ){
        return "Hold another party!"
    }

}

var numberOfPeople = 5;
var numberOfPieces = 15;
console.log(howMuchLeftOverCake(numberOfPieces, numberOfPeople));